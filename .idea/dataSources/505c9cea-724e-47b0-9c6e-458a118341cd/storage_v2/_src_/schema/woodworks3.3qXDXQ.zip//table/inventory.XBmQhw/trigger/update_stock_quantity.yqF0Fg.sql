create definer = root@localhost trigger update_stock_quantity
    before update
    on inventory
    for each row
    UPDATE furniture SET Quantity = NEW.Quantity WHERE ProductID = OLD.ProductID;

