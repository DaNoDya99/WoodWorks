create definer = root@localhost trigger update_rental_price
    before update
    on inventory
    for each row
    UPDATE furniture SET Cost = NEW.Retail_price WHERE ProductID = OLD.ProductID;

