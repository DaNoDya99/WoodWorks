create definer = root@localhost trigger createChat
    after insert
    on customer
    for each row
    INSERT INTO chats(username,employeeID,customerID) VALUES(CONCAT(NEW.Firstname," \t\t\t\t\t\t\t",NEW.Lastname),NULL,NEW.CustomerID);

