create definer = root@localhost trigger update_reordering_flag
    before update
    on inventory
    for each row
BEGIN
    IF NEW.Quantity <= OLD.Reorder_point THEN
        SET NEW.Reorder_flag = 1;
    ELSE
    	SET NEW.Reorder_flag = 0;
    END IF;
END;

